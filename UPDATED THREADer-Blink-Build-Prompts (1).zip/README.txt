THREADer — Blink.new Build Prompts

Use the numbered prompts in order:
01 Core App & UI
02 Backend Architecture
03 Facebook/Meta Integration
04 Thread Preview
05 PDF Export
06 Image Export
07 Security & Privacy
08 Demo Mode & Testing
09 Deployment & README

Paste each prompt into Blink.new only after the previous stage is working.
Do not bypass Facebook/Meta access restrictions or authentication.
